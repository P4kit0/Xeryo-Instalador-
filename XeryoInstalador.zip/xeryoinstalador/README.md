# AfterFORMAT
Script written in Powershell with GUI for faster installation of programs after Windows installation.
Uses:
- Winget
- Chocolatey
- Links to application pages that do not support the above
- Windows registry entries

![image](https://user-images.githubusercontent.com/23260174/154798186-a205e77c-cb33-4e4e-abca-68892d02b17d.png)


# Paste this command into Powershell (admin):

iex ((New-Object System.Net.WebClient).DownloadString("https://raw.githubusercontent.com/obeliksgall/AfterFORMAT/main/AfterFORMAT.ps1"))

Or

iwr -useb "https://raw.githubusercontent.com/obeliksgall/AfterFORMAT/main/AfterFORMAT.ps1" | iex


# Application list (for version 0.4.1)
7-Zip;  AdGuard;  Audacity;  Battle.net;  Bethesda.net Launcher;  Discord;  DisplayCAL;  EA app;  
Epic Games Launcher;  GOG GALAXY;  Google Chrome;  HashTab;  KeePass;  K-Lite Codec Pack;  
Logitech G HUB;  MediaInfo;  Minecraft Launcher;  MSI Afterburner;  Notepad++;  OBS Studio;  
Oracle VM VirtualBox;  Origin;  PuTTY; Remove Empty Directories;  Samsung DeX;  SoundSwitch;  
Spotify;  Steam;  SyncTrayzor;  TeamSpeak 3;  TeamViewer;  Total Commander;  Ubisoft Connect;  
VLC media player;  Wargaming.net Game Center;  WinSCP;  Adobe Creative Cloud;  Corsair iCUE 4;  
ShareX;  Touch Portal;  
